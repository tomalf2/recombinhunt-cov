import json
from os.path import sep

class Output:
    def write(self):
        raise NotImplementedError
    
    def write_on_error(self):
        raise NotImplementedError

    
class ExperimentJSONFormatter:
    def __init__(self, output_dir_path):
        self.ouput_dir_path = output_dir_path

    def write(self, output_name, experiment):
        super().__init()
        output = {
            "genome": experiment.genome_view.describe(),
            "AIK": experiment.aik,
            "p_values": {k1+" vs "+k2: experiment.__format_pvalue(v) for (k1, k2), v in experiment.p_values.items()},
            "flags": ", ".join(experiment.get_flags() or "-")
        }
        output_file_path = self.ouput_dir_path + sep + output_name
        with open(output_file_path, "w") as out_file:
            json.dumps(output, out_file)

    def write_on_error(self, output_name, exception_msg):
        super().__init__()
        output = {
                "exception": exception_msg,
            }
        output_file_path = self.ouput_dir_path + sep + output_name
        with open(output_file_path, "w") as out_file:
            json.dumps(output, out_file)
