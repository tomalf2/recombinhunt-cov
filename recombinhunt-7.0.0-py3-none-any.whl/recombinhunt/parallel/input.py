class Input:
    def count(self):
        raise NotImplementedError

    def get_one_input(self):
        raise NotImplementedError


class TSV(Input):
    """
    Wrapper around a TSV file with optional header (first row), one row per sequence, and 3 TAB-separated columns: name, assinged_variant, nuc_changes.
    Nuc_changes should a COMMA-separated list of nucleotide changes
    """
    def __init__(self, input_file_path, has_header=True, read_max_lines=None) -> None:
        self.input_file_path = input_file_path
        self.has_header = has_header
        # n lines and max lines
        self._user_read_max_lines = read_max_lines
        self._n_lines_file = self._count()

    def count(self):
        """
        Returns the maximum between the number of lines in the file and read_max_lines if specified on object creation
        """
        if self._user_read_max_lines and 0 < self._user_read_max_lines < self._n_lines_file:
            return self.read_max_lines
        else:
            return self._n_lines_file
    
    def _count(self):
        """
        Private function to count the number of lines in the file
        """
        n_lines = 0
        with open(self.input_file_path, "r") as input_file:
            for l in input_file:
                n_lines += 1
        if self.has_header:
            n_lines -= 1
        return n_lines

    def get_one_input(self):
        with open(self.input_file_path, "r") as input_file:
            if self.has_header:
                input_file.readline()
            for n_line in range(self.count()):
                l = input_file.readline()
                name, assigned_variant, changes_str = l.rstrip("\n").strip().split("\t")
                changes_list = changes_str.split(",")
                yield (name, assigned_variant, changes_list)
